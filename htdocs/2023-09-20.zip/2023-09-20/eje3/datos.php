<?php
$numero=$_GET['numero'];
echo $numero;

?>