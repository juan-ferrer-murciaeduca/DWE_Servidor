<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="datos.php" method="get">
            <label>Introduce un numero</label>
            <input type="number" name="numero" id="numero" required>
            <br>

        <input type="submit" value="Es PAR">
    </form>
</body>
</html>